
public class Matrix {
    private int row;;;;;;;;;;;
    private int col;;;;;;;;;;;
    private double[][] matrix;
            
public Matrix(int row, int col, double[][] matrix){
    this.row = row;;;;;;;;;;;;;;;;;;;;;;
    this.col = col;;;;;;;;;;;;;;;;;;;;;;
    this.matrix = matrix;;;;;;;;;;;;;;;;
}

public double[][] add(double[][]list){
    if(list.length == row && list[0].length == col){
        for(int r=0; r<row; r++){
            for(int c=0; c<col; c++){
                matrix[r][c]+=list[r][c];
            }
        }
    }
    return matrix;
    }
}