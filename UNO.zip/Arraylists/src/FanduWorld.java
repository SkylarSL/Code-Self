
import java.io.*;

import java.util.*;

public class FanduWorld {
    //initialize 2 worlds, planet holds int, plantsex holds M/F
    static int[][] planet = new int[100][100];
    static String[][] planetsex = new String[100][100];
    
    public static void main(String[]args)throws IOException{
        //read the first line and get the number of years
        BufferedReader in = new BufferedReader(new FileReader("src/RealFanduIn.txt"));
        String Read = in.readLine();
        int years = Integer.parseInt(Read);
        Read = in.readLine();
        StringTokenizer Fan = new StringTokenizer(Read, "(), ");
        //make M and F counters
        int M = 0;
        int F = 0;
        //tell user what is male and female
        System.out.println("\033[0;31m"+"red"+"\033[0m"+" = female");
        System.out.println("\033[0;34m"+"blue"+"\033[0m"+" = male");
        //while the read line is not equal to null do the following
        while(Read!=null){
            Fan = new StringTokenizer(Read, "(), ");
            //get the Fnadu's gender
            String Fandu = Fan.nextToken();
            //get the age and (x,y) position of the Fandu
            int age = Integer.parseInt(Fan.nextToken());
            int x = Integer.parseInt(Fan.nextToken());
            int y = Integer.parseInt(Fan.nextToken());
            //planetsex at (x,y) is equal to Fandu's gender
            planetsex[x][y] = Fandu;
            //planet at (x,y) is equal to Fandu's age
            planet[x][y] = age;
            Read = in.readLine();
            //add up number of females and males at start
            if(Fandu.equals("M")){
                M++;
            }else{
                F++;
            }
            
        }
        //make new Fandus object, take in age array, gender array, and number of males/females
        Fandus fandus = new Fandus(planet, planetsex, M, F);
        //while year is less than stated years, do the following
        for(int year=0; year<years+1; year++){

            //call for birth of Fandus
            fandus.birth();

            //assign planet to new age planet
            planet = fandus.pla();
            //assign planetsex to new gender planet
            planetsex = fandus.plas();
            //return number of males
            M = fandus.male();
            //return number of females
            F = fandus.female();
            //kill Fandus
            fandus.death();
            //print out year
            System.out.println("\nYear "+year);
            //print out the Fandu at [i][j] for age artay, make number blue/red based on male or female
            for(int i=1;i<11;i++){
                for(int j=1;j<11;j++){
                    if(planet[i][j] !=0 && planetsex[i][j].equals("F")){
                        System.out.print("\033[0;31m"+planet[i][j]+"\033[0m"+" ");
                    }else if(planet[i][j] !=0 && planetsex[i][j].equals("M")){
                        System.out.print("\033[0;34m"+planet[i][j]+"\033[0m"+" ");
                    }else{
                        System.out.print(planet[i][j]+" ");
                    }
                }
                System.out.println("");
            }

            //increase age of each fandu
            fandus.age();

            //intek new planet, planetsex, and number of males and females
            fandus = new Fandus(planet, planetsex, M, F);
        } 
    }
}

