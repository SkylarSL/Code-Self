import QueueStack.Stack;
import QueueStack.Queue;
import java.io.*;
import java.util.*;
public class carPractice {
    public static void main(String[]args)throws IOException{
    
            //STACK
            Stack<carStuff> s = new Stack();
            
            s.push(new carStuff("Toyota","Corolla",2009,175000));
            s.push(new carStuff("Ford","500",2005,189000));
            s.push(new carStuff("Ford","500",2005,189000));
            s.push(new carStuff("Toyota","Corolla",2009,175000));
            
            System.out.println("Take off first 2 cars from the stack:");
            for(int i=0;i<2;i++){
                carStuff c = s.pop();
                System.out.println("Took off "+ c.display());
            }
            
            System.out.println("Remove remaining cars");
            while(!s.isEmpty()){
                System.out.println("Took off "+s.pop().display());
            }
            
            System.out.println("ALL CARS REMOVED");
            while(!s.isEmpty()){
                System.out.println("There are "+s.size());
            }
            
            System.out.println("");
            System.out.println("");
            System.out.println("");
            
            //QUEUE
            Queue<carStuff> S = new Queue();
            
            S.enqueue(new carStuff("Toyota","Corolla",2009,175000));
            S.enqueue(new carStuff("Ford","500",2005,189000));
            S.enqueue(new carStuff("Ford","500",2005,189000));
            S.enqueue(new carStuff("Toyota","Corolla",2009,175000));
            S.enqueue(new carStuff("Toyota","Corolla",2009,175000));
            
            System.out.println("Take off first 2 cars from the stack:");
            for(int i=0;i<2;i++){
                carStuff c = S.dequeue();
                System.out.println("Took off "+ c.display());
            }
            
            System.out.println("Remove remaining cars");
            while(!S.isEmpty()){
                System.out.println("Took off "+S.dequeue().display());
            }
            
            System.out.println("ALL CARS REMOVED");
            while(!S.isEmpty()){
                System.out.println("There are "+S.size());
            }
    }
}
