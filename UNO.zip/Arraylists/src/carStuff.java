
import java.util.*;

//Accepts any type of object when creating stack array (doesnt have to be T)
public class carStuff {
    private String company;
    private String model;
    private int year;
    private int km;
   
    //creates the stuff you need
    public carStuff(String company, String model, int year, int km){
        this.company = company;
        this.model = model;
        this.year = year;
        this.km = km;
    }
    
    public String display(){
        return company+" "+model+" "+year+" "+km;
    }
    

    


}
