
public class patterns {
    public static void main(String[]args){
        int [][] pattern = new int[5][5];
        int i =25;
        for(int r=0; r<5; r++){
            
            for(int c=0; c<5; c++){

                pattern[r][c] = i;
                i--;
                System.out.print(pattern[r][c]+" ");
            }
            
            System.out.println("");
        }
        
    }
}
