
public class Fandus {
    private int[][] planet;
    private String[][] planets;
    private int Male;
    private int Female;
    //take in the new variables from the main class
    public Fandus(int[][] planet, String[][]planets, int male, int female){
        this.planet = planet;
        this.planets = planets;
        this.Male = male;
        this.Female = female;
    }
    //make a new fandu if there is a female and male surrounding the space
    //if Female is more than male make a male, else make a female
    public void birth(){
        if(Female>Male){
            for(int i=1;i<11;i++){
                for(int j=1;j<11;j++){
                    boolean tf = false;
                    for(int x=-1;x<=1;x++){
                        for(int y=-1;y<=1;y++){
                            if(planet[i][j] ==0 && planet[i+x][j+y] >=2 && planet[i+x][j+y] <=6 && planets[i+x][j+y].equals("M")){
                                tf = true;
                            }
                        }
                    }
                    for(int x=-1;x<=1;x++){
                        for(int y=-1;y<=1;y++){
                            if(tf==true && planet[i+x][j+y] >=2 && planet[i+x][j+y] <=4 && planets[i+x][j+y].equals("F")){
                                tf = false;
                                planets[i][j] = "M";
                                Male +=1;
                                planet[i][j]=1;
                            }
                        }
                    }
                }
            }
        }else{
            for(int i=1;i<11;i++){
                for(int j=1;j<11;j++){
                    boolean tf = false;
                    for(int x=-1;x<=1;x++){
                        for(int y=-1;y<=1;y++){
                            if(planet[i][j] ==0 && planet[i+x][j+y] >=2 && planet[i+x][j+y] <=6 && planets[i+x][j+y].equals("M")){
                                tf = true;
                            }
                        }
                    }
                    for(int x=-1;x<=1;x++){
                        for(int y=-1;y<=1;y++){
                            if(tf==true && planet[i+x][j+y] >=2 && planet[i+x][j+y] <=4 && planets[i+x][j+y].equals("F")){
                                tf = false;
                                planets[i][j] = "F";
                                Female +=1;
                                planet[i][j]=1;
                            }   
                        }
                    }
                }
            }
        }
    }
    //kill a Fandu once it reaches the age of 8 and minus 1 to the male or female population
    public void death(){
        for(int i=1;i<11;i++){
            for(int j=1;j<11;j++){
                if(planet[i][j]>=8 && planets[i][j].equals("M")){
                    Male-=1;
                    planet[i][j]=0;
                    planets[i][j]=null;
                }else if(planet[i][j]>=8 && planets[i][j].equals("F")){
                    Female-=1;
                    planet[i][j]=0;
                    planets[i][j]=null;
                }
            }
        }
    }
    //add 1 to each fandu
    public void age(){
        for(int i=1;i<11;i++){
            for(int j=1;j<11;j++){
                if(planet[i][j]!=0){
                    planet[i][j]+=1;
                }
            }
        }
    }
    //return number of males
    public int male(){
        return Male;
    }
    //return number of femals
    public int female(){
        return Female;
    }
    //return age array
    public int[][] pla(){
        return planet;
    }
    //return gender array
    public String[][] plas(){
        return planets;
    }
}
